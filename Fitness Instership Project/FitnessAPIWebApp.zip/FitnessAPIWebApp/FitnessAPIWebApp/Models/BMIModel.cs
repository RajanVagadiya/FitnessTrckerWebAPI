﻿using System.ComponentModel.DataAnnotations;

namespace FitnessAPIWebApp.Models
{
    public class BMIModel
    {
        public int Id { get; set; }
        public double height { get; set; }
        public double weight { get; set; }
        public double bmi { get; set; }

        //[Required(ErrorMessage = "The category field is required.")]
        public string category { get; set; }

        //[Required(ErrorMessage = "The suggestions field is required.")]
        public string suggestions { get; set; }

        public DateOnly currentdate { get; set; } // Change to DateTime for compatibility with form binding
        public int userId { get; set; }

      
    }
}
