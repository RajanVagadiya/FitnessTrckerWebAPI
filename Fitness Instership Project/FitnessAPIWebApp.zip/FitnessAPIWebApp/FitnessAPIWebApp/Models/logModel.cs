﻿namespace FitnessAPIWebApp.Models
{
    public class logModel
    {
        public string email { get; set; }
        public string password { get; set; }
    }
}
