﻿namespace FitnessAPIWebApp.Models
{
    public class ActivityModel
    {
        public int activityId { get; set; }

        public string activity { get; set; }

        public double duration { get; set; }

        public DateOnly activitydate { get; set; }

        public double calories { get;set; }

        public double weightloss { get; set; }

        public int userId { get; set; }
    }
}
