﻿namespace FitnessAPIWebApp.Models
{
    public class CredModel
    {
        public int userId { get; set; }

        public string name { get; set; }

        public string email {  get; set; }

        public string password { get; set; }
        public double Mobile {  get; set; }
        public string gender {  get; set; }
    }
}
