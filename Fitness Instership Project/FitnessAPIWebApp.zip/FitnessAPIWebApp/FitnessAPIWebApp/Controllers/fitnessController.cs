﻿using System.Data;
using System.Reflection.PortableExecutable;
using FitnessAPIWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace FitnessAPIWebApp.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class fitnessController : ControllerBase
    {
        private readonly string dbcon = "Data Source=(localdb)\\MSSQLLocalDB; Initial Catalog= fitnessDB; Integrated Security=TRUE; MultipleActiveResultSets=True;";

        [HttpPost]

        public ActionResult<CredModel> registerUser([FromForm] CredModel user)
        {
            using var con = new SqlConnection(dbcon);
            con.Open();
            var cmd = new SqlCommand("InsertUsers", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", user.name);
            cmd.Parameters.AddWithValue("@email", user.email);
            cmd.Parameters.AddWithValue("@password", user.password);
            cmd.Parameters.AddWithValue("@mobile", user.Mobile);
            cmd.Parameters.AddWithValue("@gender", user.gender);
            var result = cmd.ExecuteNonQuery();
            con.Close();
            if (result > 0)
            {
                return Ok(new { message = "User Inserting successfully." });
            }
            else
            {
                return BadRequest(new { message = "Failed to Inserting User." });
            }

        }

        [HttpPost]
        public ActionResult<logModel> LoginUsr([FromForm] logModel regUsr)
        {
            using var connection = new SqlConnection(dbcon);
            connection.Open();
            var checkCmd = new SqlCommand("SELECT userId, email, password FROM userCred WHERE email = @email", connection);
            checkCmd.Parameters.AddWithValue("@email", regUsr.email);
            using var reader = checkCmd.ExecuteReader();
            if (reader.Read())
            {
                var dbEmail = reader["email"].ToString();
                var dbPassword = reader["password"].ToString();
                var userId = reader["userId"].ToString();

                if (dbEmail == regUsr.email && dbPassword == regUsr.password)
                {
                    connection.Close();
                    return Ok(new { success = true, message = "Login successful!", userId });
                }
                else if (dbEmail == regUsr.email)
                {

                    connection.Close();
                    return Ok(new { success = false, message = "Password Incorrect!" });
                }
                else
                {
                    connection.Close();
                    return Ok(new { success = false, message = "Email doesn't match. Please try again." });
                }
            }
            else
            {
                connection.Close();
                return Ok(new { success = false, message = "You are not registered. Please register first." });
            }
        }

        [HttpPost("demo")]
        public ActionResult<BMIModel> setBMI([FromBody] BMIModel bmi)
        {
            // Open SQL connection
            using var connection = new SqlConnection(dbcon);
            connection.Open();

            // Prepare SQL command to call the stored procedure
            var insertCmd = new SqlCommand("InsertBmiRecord", connection);
            insertCmd.CommandType = CommandType.StoredProcedure;

            // Add parameters to the SQL command
            insertCmd.Parameters.AddWithValue("@height", bmi.height);
            insertCmd.Parameters.AddWithValue("@weight", bmi.weight);
            insertCmd.Parameters.AddWithValue("@bmi", bmi.bmi); // Store BMI (assumed already calculated)
            insertCmd.Parameters.AddWithValue("@category", bmi.category); // Category value
            insertCmd.Parameters.AddWithValue("@suggestions", bmi.suggestions); // Suggestions value
            insertCmd.Parameters.AddWithValue("@currentdate", bmi.currentdate); // Current date value
            insertCmd.Parameters.AddWithValue("@userId", bmi.userId); // User ID

            // Execute SQL command and check if the record was inserted successfully
            var result = insertCmd.ExecuteNonQuery();
            connection.Close();

            // Return appropriate response based on the result
            if (result > 0)
            {
                return Ok(new { message = "BMI Record Inserted Successfully" });
            }
            else
            {
                return BadRequest(new { message = "Failed to Insert BMI Record." });
            }

        }

        [HttpGet]
        public ActionResult<List<BMIModel>> getBMIRecords(int userId)
        {
            List<BMIModel> bmiRecords = new List<BMIModel>();
            using var connection = new SqlConnection(dbcon);
            connection.Open();
            var selQuery = "SELECT * FROM bmi WHERE userId = @UserId";  // Filter records by userId
            var insertCmd = new SqlCommand(selQuery, connection);
            insertCmd.Parameters.AddWithValue("@UserId", userId);  // Add userId as a parameter to the query

            using (var reader = insertCmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    var bmiRecord = new BMIModel
                    {
                        height = Convert.ToDouble(reader["height"]),
                        weight = Convert.ToDouble(reader["weight"]),
                        bmi = Convert.ToDouble(reader["bmi"]),
                        category = reader["category"].ToString(),
                        suggestions = reader["suggestions"].ToString(),
                        currentdate = DateOnly.FromDateTime(Convert.ToDateTime(reader["currentdate"])),
                    };
                    bmiRecords.Add(bmiRecord);
                }
            }
            return Ok(bmiRecords);
        }

        [HttpPost]
        public ActionResult<ActivityModel> setActivity([FromBody] ActivityModel actModel)
        {
            using var con = new SqlConnection(dbcon);
            con.Open();
            var insertCmd = new SqlCommand("InsertActivity", con);
            insertCmd.CommandType = CommandType.StoredProcedure;

            // Add parameters to the SQL command
            insertCmd.Parameters.AddWithValue("@activity", actModel.activity);
            insertCmd.Parameters.AddWithValue("@duration", actModel.duration);
            insertCmd.Parameters.AddWithValue("@activitydate", actModel.activitydate); // Store BMI (assumed already calculated)
            insertCmd.Parameters.AddWithValue("@calories", actModel.calories); // Category value
            insertCmd.Parameters.AddWithValue("@weightloss", actModel.weightloss); // Suggestions value
            insertCmd.Parameters.AddWithValue("@userId", actModel.userId);
            var result = insertCmd.ExecuteNonQuery();
            con.Close();

            // Return appropriate response based on the result
            if (result > 0)
            {
                return Ok(new { message = "activity Record Inserted Successfully" });
            }
            else
            {
                return BadRequest(new { message = "Failed to Insert Activity Record." });
            }

        }

        [HttpGet]
        public ActionResult<List<ActivityModel>> getActivityRecords(int userId)
        {
            List<ActivityModel> activityRecords = new List<ActivityModel>();
            using var connection = new SqlConnection(dbcon);
            connection.Open();
            var selQuery = "SELECT * FROM activity WHERE userId = @UserId";  // Filter records by userId
            var insertCmd = new SqlCommand(selQuery, connection);
            insertCmd.Parameters.AddWithValue("@UserId", userId);
            var reader = insertCmd.ExecuteReader();

            while (reader.Read())
            {
                var activityRecord = new ActivityModel
                {
                    activity = Convert.ToString(reader["activity"]),
                    duration = Convert.ToDouble(reader["duration"]),
                    activitydate = DateOnly.FromDateTime(Convert.ToDateTime(reader["activitydate"])),
                    calories = Convert.ToDouble(reader["calories"]),
                    weightloss = Convert.ToDouble(reader["weightloss"]),
                    userId = Convert.ToInt32(reader["userId"])
                };
                activityRecords.Add(activityRecord);
            }
            return Ok(activityRecords);
        }
        

    }
}
